package Week5.Lab2;

public interface Flying {
	public String name = "";
	
	public abstract String getName();
	public abstract void setName(String name);
	
	public abstract String takeOff();

}
