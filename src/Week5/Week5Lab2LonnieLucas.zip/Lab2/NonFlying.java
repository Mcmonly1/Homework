package Week5.Lab2;

public interface NonFlying {
	
	public abstract String getName();
	
	public abstract void setName(String name);
	
	public abstract String movement();

}
